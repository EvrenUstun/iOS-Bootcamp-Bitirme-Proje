//
//  ProfileViewController.swift
//  Charger
//
//  Created by Evren Ustun on 26.06.2022.
//

import UIKit

class ProfileViewController: UIViewController {
    
    @IBOutlet private weak var profileCardView: UIView!
    @IBOutlet private weak var userEmailLabel: UILabel!
    @IBOutlet private weak var userDeviceUDIDLabel: UILabel!
    @IBOutlet private weak var logoutButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setupUI()
    }
    
    func setupUI() {
//        let appearance = UINavigationBarAppearance()
//        appearance.configureWithOpaqueBackground()
//        appearance.backgroundColor = UIColor.lightGray // your colour here
//        
//        navigationController?.navigationBar.standardAppearance = appearance
//        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        
        // Gradient background settings.
        prepareGradientBackground()
        
        // This will change the navigation bar background color.
//        let attrs = [
//            NSAttributedString.Key.foregroundColor: UIColor.white,
//            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 20.0, weight: .bold)
//        ]
//        let appearance = UINavigationBarAppearance()
//        appearance.configureWithOpaqueBackground()
//        appearance.backgroundColor = UIColor(red: 0.26, green: 0.29, blue: 0.33, alpha: 1)
//        appearance.titleTextAttributes = attrs
//        navigationController?.navigationBar.standardAppearance = appearance;
//        navigationController?.navigationBar.scrollEdgeAppearance = navigationController?.navigationBar.standardAppearance
//        self.navigationItem.backBarButtonItem?
        self.title = "Profil"
        
        // profile card shadow
        profileCardView.layer.shadowColor = UIColor.black.cgColor
        profileCardView.layer.shadowOpacity = 1
        profileCardView.layer.shadowOffset = .zero
        profileCardView.layer.shadowRadius = 10
        
        profileCardView.layer.shadowPath = UIBezierPath(rect: profileCardView.bounds).cgPath
        
        profileCardView.layer.rasterizationScale = UIScreen.main.scale
        
        profileCardView.layer.cornerRadius = 10
        
        userEmailLabel.text = ProjectRepository.user.email
        
        userDeviceUDIDLabel.text = ProjectRepository.deviceUDID
        
    }
    
    @IBAction func logoutButtonPressed(_ sender: Any) {
        let logout = LogoutAPI()
        logout.logoutPostRequest { results in
            switch results{
            case .success(let code):
                if(code == 200){
                    DispatchQueue.main.async {
                        if let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as? LoginViewController {
                            self.navigationController?.pushViewController(vc, animated: true)
                        }
                    }
                }
            case .failure(let err):
                print("fail içi \(err)")
            }
        }
        
        print("log out butona tiklandi")
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
