//
//  Constant.swift
//  Charger
//
//  Created by Evren Ustun on 27.06.2022.
//

import Foundation

public struct Constants {
    static let baseUrl = "http://ec2-18-197-100-203.eu-central-1.compute.amazonaws.com:8080"
}
