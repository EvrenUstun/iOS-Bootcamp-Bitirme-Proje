//
//  HomaPageViewController.swift
//  Charger
//
//  Created by Evren Ustun on 26.06.2022.
//

import UIKit

class HomePageViewController: UIViewController {

    @IBOutlet private weak var profileButton: UIBarButtonItem!
    @IBOutlet private weak var createAppointmentButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.

        setupUI()
    }

    
    func setupUI() {
//        let appearance = UINavigationBarAppearance()
//        appearance.configureWithOpaqueBackground()
//        appearance.backgroundColor = UIColor.lightGray // your colour here
//
//        navigationController?.navigationBar.standardAppearance = appearance
//        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        
        // Gradient background settings.
        prepareGradientBackground()
        
        // This will change the navigation bar background color.
//        let attrs = [
//            NSAttributedString.Key.foregroundColor: UIColor.white,
//            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 20.0, weight: .bold)
//        ]
//        let appearance = UINavigationBarAppearance()
//        appearance.configureWithOpaqueBackground()
//        appearance.backgroundColor = UIColor(red: 0.26, green: 0.29, blue: 0.33, alpha: 1)
//        appearance.titleTextAttributes = attrs
//        navigationController?.navigationBar.standardAppearance = appearance;
//        navigationController?.navigationBar.scrollEdgeAppearance = navigationController?.navigationBar.standardAppearance
        
//        navigationController?.navigationBar.isTranslucent = true
//        navigationController?.navigationBar.backgroundColor = .clear
        
        let profileButton = UIBarButtonItem(image: UIImage(asset: Asset.users) , style: .plain, target: self, action: #selector(self.profileButtonPressed))
        navigationItem.leftBarButtonItem = profileButton
        navigationItem.leftBarButtonItem?.tintColor = Asset.solidWhite.color
        self.navigationItem.backBarButtonItem?.title = ""
        self.navigationController?.title = "Randevular"
    }
    
    @objc
    func profileButtonPressed() {
        if let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProfileViewController") as? ProfileViewController {
            navigationController?.pushViewController(vc, animated: true)
//                vc.modalPresentationStyle = .fullScreen
//                present(vc, animated: true)
        }
    }
    
    
    @IBAction func createAppointmentButtonPressed(_ sender: Any) {
        if let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SelectCityViewController") as? SelectCityViewController {
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}
