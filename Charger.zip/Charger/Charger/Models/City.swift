//
//  City.swift
//  Charger
//
//  Created by Evren Ustun on 27.06.2022.
//

import Foundation

struct Cities: Decodable{
    var cities: [String?] = []
}
